import { Brain, Activity, Users } from 'lucide-react'
import SkillCoverageMap from '@/components/ui/SkillCoverageMap'
import BurnoutRiskDashboard from '@/components/ui/BurnoutRiskDashboard'

export default function WorkforceAI() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl p-8 text-white shadow-2xl">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl">
            <Brain className="w-12 h-12" />
          </div>
          <div>
            <h1 className="text-4xl font-bold mb-2">Workforce AI Intelligence</h1>
            <p className="text-blue-100 text-lg">
              Advanced analytics for team skill coverage and burnout prevention
            </p>
          </div>
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-blue-200" />
              <div>
                <p className="text-sm text-blue-200">AI Insights</p>
                <p className="text-2xl font-bold">Real-time</p>
              </div>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-200" />
              <div>
                <p className="text-sm text-blue-200">Team Coverage</p>
                <p className="text-2xl font-bold">6 Skills</p>
              </div>
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-blue-200" />
              <div>
                <p className="text-sm text-blue-200">Risk Monitoring</p>
                <p className="text-2xl font-bold">24/7</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Skill-Based Coverage Mapping */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl border-2 border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-50 to-slate-50 dark:from-blue-900/20 dark:to-slate-900/20 p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
            <Activity className="w-7 h-7 text-blue-600" />
            Skill-Based Coverage Mapping
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Real-time tracking of team skill availability and coverage levels
          </p>
        </div>
        <div className="p-6">
          <SkillCoverageMap />
        </div>
      </div>

      {/* Burnout Risk Index */}
      <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl border-2 border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="bg-gradient-to-r from-rose-50 to-amber-50 dark:from-rose-900/20 dark:to-amber-900/20 p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
            <Brain className="w-7 h-7 text-rose-600" />
            Burnout Risk Index
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            AI-powered team wellness monitoring and burnout prevention system
          </p>
        </div>
        <div className="p-6">
          <BurnoutRiskDashboard />
        </div>
      </div>

      {/* AI Recommendations Footer */}
      <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-xl p-6 text-white shadow-lg">
        <div className="flex items-center gap-4">
          <Brain className="w-10 h-10 animate-pulse" />
          <div>
            <h3 className="text-xl font-bold mb-1">AI-Powered Insights</h3>
            <p className="text-emerald-100">
              Our advanced algorithms continuously analyze team dynamics, skill coverage, and workload patterns 
              to provide proactive recommendations for optimal workforce management and employee wellbeing.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
